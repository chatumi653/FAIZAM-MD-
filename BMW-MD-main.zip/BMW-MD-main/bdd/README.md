  <a href="https://ibb.co/N6NMDtn"><img src="https://telegra.ph/file/7cd9d893413bffb0c5bdb.jpg" alt="01" border="0" /></a>                     

  ## Legit bot made by Faizam
